<?php
// Skapa vårat root element (samma princip som <html></html> i HTML)
$xml = new SimpleXMLElement('<books></books>');
 
// Gå igenom (loop) alla våra böcker, varje bok är en array
// innehållande bokens attribut (titel, författare, etc.).
foreach ($books as $attributes) {
    // Skapa ett XML element (book).
    $book = $xml->addChild('book');

    // Gå igenom attributen för en bok och skapa
    // ett XML element för varje.
    foreach ($attributes as $key => $value) {
         $book->addChild($key, $value);
    }
}

// Slutligen skriv all XML till filen books.xml
file_put_contents('books.xml', $xml->asXML());


$books = array(
    array(
        'title' => 'Pet Sematary',
        'author' => 'Stephen King',
        'isbn-13' => '978-0743412278'
    ),
    array(
        'title' => 'Total Recall: My Unbelievably True Life Story',
        'author' => 'Arnold Schwarzenegger',
        'isbn-13' => '978-1451662443'
    ),
    array(
        'title' => 'The Hobbit',
        'author' => 'J.R.R Tolkien',
        'isbn-13' => '978-0137171668'
    ),
    array(
        'title' => 'American Psycho',
        'author' => 'Bret Easton Ellis',
        'isbn-13' => '978-0679735779'
    ),
    array(
        'title' => 'The Divine Comedy',
        'author' => 'Dante Alighieri',
        'isbn-13' => '978-1619490215'
    )
);


// Använd ett exempel i taget, kommentera bort de som inte används (annars blir det problem)

// =====================
// To CSV
// =====================


// Öppna vald fil för att skriva till (w).
$output = fopen('books_comma.csv', 'w');

// Första raden i vår CSV fil ska innehålla kolumntitlarna.
// Funktionen "array_keys" hämtar alla nycklar (index) från
// en array, för enkelhetens skull väljer vi den första.
fputcsv($output, array_keys($books[0]));

// Gå igenom (loop) alla böcker.
foreach ($books as $book) {
    // För varje bok så konverterar vi denna till en korrekt
    // formaterad CSV rad och sparar den i vår fil.
    fputcsv($output, $book);
}

// Slutligen stänger vi vår fil - klart!
fclose($output);


// =====================
// To TSV
// =====================

// Öppna en fil för att skriva till
$output = fopen('books_tab.csv', 'w');
// Första raden som kolumntitlar, observera citationstecken kring \t
fputcsv($output, array_keys($books[0]), "\t");
// Gå igenom alla böcker
foreach ($books as $book) {
    // Gör om varje bok till en korrekt formaterad CSV rad
    fputcsv($output, $book, "\t");
}
// Stäng filen
fclose($output);

// =====================
// To JSON
// =====================

// Konvertera vår array till JSON
$json = json_encode( array('books' => $books) );
// Skriv våran data till JSON-filen books.json
file_put_contents('books.json', $json);

// För att få en finare formaterad JSON fil används följande istället
$json = json_encode( array('books' => $books), JSON_PRETTY_PRINT );

// =====================
// To XML
// =====================

$xml = new SimpleXMLElement('<books></books>');
 
// Loopa genom alla böcker, varje bok består av attribut (titel, författare, etc.)
foreach ($books as $attributes) {
    $book = $xml->addChild('book');
    // Skapa ett XML element för varje attribut
    foreach ($attributes as $key => $value) {
         $book->addChild($key, $value);
    }
}
// Skriv all XML till books.xml
file_put_contents('books.xml', $xml->asXML());

// ====================================
// För att få en nedladdningsbar fil
// =====================================

// =====================
// To CSV
// =====================

// header('Content-type: text/csv');
// header('Content-Disposition: attachment; filename=books.csv');
// header('Pragma: no-cache');
// header('Expires: 0');
// 
// $output = fopen('php://output', 'w');
// 
// // Första raden som kolumntitlar
// fputcsv($output, array_keys($books[0]));
// 
// foreach ($books as $book) {
//     fputcsv($output, $book);
// }
// 
// fclose($output);

// =====================
// To TSV
// =====================

// header('Content-type: text/csv');
// header('Content-Disposition: attachment; filename=books.csv');
// header('Pragma: no-cache');
// header('Expires: 0');
// 
// $output = fopen('php://output', 'w');
// 
// // Första raden som kolumntitlar
// fputcsv($output, array_keys($books[0]), "\t");
// 
// foreach ($books as $book) {
//     fputcsv($output, $book, "\t");
// }
// 
// fclose($output);

// =====================
// To JSON
// =====================

// header('Content-type: application/json');
// header('Content-Disposition: attachment; filename=books.json');
// header('Pragma: no-cache');
// header('Expires: 0');
// 
// echo json_encode( array('books' => $books) );

// Formatted output
// echo json_encode( array('books' => $books), JSON_PRETTY_PRINT );
 
// =====================
// To XML
// =====================

// $xml = new SimpleXMLElement('<books></books>');
 
// Loop through all of the books,
// each book is made up of attributes (title, author, etc.)
// foreach ($books as $attributes) {
//     $book = $xml->addChild('book');
// 
//     // For each attribute of the book - add a child
//     foreach ($attributes as $key => $value) {
//          $book->addChild($key, $value);
//     }
// }
// 
// header('Content-type: text/xml');
// header('Content-Disposition: attachment; filename=books.xml');
// header('Pragma: no-cache');
// header('Expires: 0');
// echo $xml->asXML();

// Formatted output
// $dom = new DOMDocument('1.0');
// $dom->preserveWhitespace = false;
// $dom->formatOutput = true;
// $dom->loadXML($xml->asXML());
// echo $dom->saveXML();

// Example
// $xml = new SimpleXMLElement('<tracks></tracks>');
// 
// for ($i = 1; $i <= 5; $i++) {
//     $track = $xml->addChild('track');
//     $track->addChild('title', "Track $i - Title");
//     $track->addChild('length', "0$i:00");
// }
// 
// header('Content-type: text/xml');
// echo $xml->asXML();
?>
