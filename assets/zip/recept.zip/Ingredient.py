class Ingredient:

    def __init__(self, title, amount, unit):
        self.title = title
        self.amount = amount
        self.unit = unit
        
    def __str__(self):
        return "{} ({}{})".format(self.title, self.amount, self.unit)
