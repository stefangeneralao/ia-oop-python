#from Ingredient import Ingredient

class Recipe:

    def __init__(self, title, ingredients, recipe_type, vegitarian, description, time):
        self.title = title
        self.ingredients = ingredients # En lista på ingrediensobjekt
        self.recipe_type = recipe_type
        self.vegitarian = vegitarian
        self.description = description
        self.time = time

    def __str__(self):
        return self.title


''' Exempel
class VegRecipe(Recipe):

    def __init__(self, *args, **kwargs):
        self.vegitarian = True
        super().__init__(*args, **kwargs)
'''
