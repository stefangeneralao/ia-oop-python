from CardPlayer import CardPlayer
from Hand import Hand


class Dealer(CardPlayer):
    '''A dealer in black jack

    Args:
        name (str) : name of the dealer
    '''

    def __init__(self, name):
        '''Creates an instance of Dealer

        Args:
            name (str) : the name of the dealer
        '''
        super().__init__(name)

    def draw_card(self, player, deck):
        '''Draws a card from the deck to a hand of a player

        Args:
            player (CardPlayer) : the player with the hand
                                  that will recieve the card
            deck (Deck) : The deck from where the card is drawn
        '''
        player.hand.add_card(deck.take_card())
