from Hand import Hand


class CardPlayer():
    '''Represents a card player

    Args:
        name (str) : the name of the player

    '''

    def __init__(self, name):
        '''A player has a hand (instance of Hand) and a name'''
        self.hand = Hand([])
        self.name = name

    def get_name(self):
        '''Get the name of the card player

        Returns: str
        '''
        return self.name

    def set_name(self, name):
        '''Set the name of the card player

        Args:
            name (str) : the new name of the player

        Returns:
            str : the name of the player
        '''
        self.name = name
        return self.name
