import random
import time
from Player import Player
from Dealer import Dealer
from Deck import Deck
from Hand import Hand


class Blackjack():
    '''The ultimate game of black jack!'''

    def __init__(self):
        self.dealer = None
        self.player = None
        self.deck = None

    def play(self):
        '''Handles the playing part of the game'''
        self.welcome()
        while self.player.get_balance() > 0 and input("Vill du spela? (y/n) ") == "y":
            self.deck = Deck()
            self.player.hand = Hand([])
            self.dealer.hand = Hand([])
            # Prints status
            self.status()
            # Get amount to play for
            amount = int(input("Hur mycket vill du satsa? "))
            win = False
            # Draw the first two cards to dealer and player
            self.dealer_draw_cards()
            while not self.player.hand.is_black_jack() and not self.player.hand.is_busted() and input("Vill du dra ett nytt kort? (y/n) ") == "y":
                self.player.hand.add_card(self.deck.take_card())
                print("\n{:<10}: {}\n".format(self.player.get_name(), self.player.hand))
            if self.player.hand.is_black_jack():
                win = True
            elif self.player.hand.is_busted():
                print("Du blev tyvärr tjock!")
            else:
                print("\n- Dealers tur")
                print("{:<10}: {}\n".format(self.dealer.get_name(), self.dealer.hand))
                while self.dealer.hand.total_sum() < 16:
                    time.sleep(0.5)
                    self.dealer.hand.add_card(self.deck.take_card())
                    print("{:<10}: {}\n".format(self.dealer.get_name(), self.dealer.hand))
                if self.dealer.hand.is_black_jack():
                    print("\n- " + self.dealer.get_name() + " fick Black Jack!")
                elif self.dealer.hand.is_busted():
                    print("\n -" + self.dealer.get_name() + " blev tjock!")
                    win = True
                else:
                    if self.player.hand.total_sum() > self.dealer.hand.total_sum() and self.dealer.hand.total_sum() < 22:
                        win = True
            if win:
                print("\nSnyggt jobbat!")
                self.player.add_money(amount)
            else:
                print("\nBättre lycka nästa gång!")
                self.player.remove_money(amount)
            print("*" * 28)
        if self.player.get_balance() == 0:
            print("\nDu gick bankrutt, trist!")
        else:
            print("\nVälkommen tillbaka! =)")

    def welcome(self):
        '''Welcomes the user to the game'''
        print("=" * 40)
        print("Välkommen till Black Jack!")
        print("=" * 40)
        name = input("Vad heter du? ")
        money = eval(input("Hur mycket vill du spela för? "))
        self.player = Player(name, money)
        dealer = input("Vad heter dealerna idag? ")
        self.dealer = Dealer(dealer)
        print("\nVälkommen " + name + " och lycka till!")
        print("- " + self.dealer.get_name() + " är dealer idag")
        print("=" * 40)

    def status(self):
        '''Prints a status for the player'''
        print()
        print("*" * 10 + " Status " + "*" * 10)
        print(self.player)
        print("*" * 28)

    def dealer_draw_cards(self):
        '''Draw two cards to player/dealer in the beginning of every game'''
        for i in range(2):
            self.dealer.draw_card(self.dealer, self.deck)
            self.dealer.draw_card(self.player, self.deck)
        print("\nUtdelade kort:")
        print("*"*28)
        print("{:<10}: {}".format(self.player.get_name(), self.player.hand))
        print("{:<10}: {}".format(self.dealer.get_name(), self.dealer.hand.get_first_card()))

game = Blackjack()
game.play()
