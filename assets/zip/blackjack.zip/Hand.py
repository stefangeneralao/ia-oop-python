from Card import Card


class Hand():
    '''Represents a hand of cards

    Args:
       cards (list) : the cards in the hands
      '''

    def __init__(self, cards):
        self.cards = cards
        self.is_soft = False
        total = 0

    def add_card(self, card):
        '''Adds a card to the hand

        Args:
            card (Card) : A card

        Returns:
            list : A list of all the cards in the deck
        '''
        self.cards.append(card)
        total = 0
        for card in self.cards:
            total += card.get_value(self.is_soft)
        if total > 21:
            self.is_soft = True
        return self.cards

    def is_busted(self):
        '''Checks if a hand i busted

        Returns:
            Boolean : True => busted, False => not busted
        '''
        cards_sum = 0
        for card in self.cards:
            cards_sum += card.get_value(self.is_soft)
        if cards_sum > 21:
            return True
        else:
            return False

    def get_first_card(self):
        return self.cards[0]

    def is_black_jack(self):
        '''Checks if a hand is black jack

        Returns:
            Boolean : True => black jack, False => not black jack
        '''
        cards_sum = 0
        for card in self.cards:
            cards_sum += card.get_value(self.is_soft)
        if cards_sum == 21:
            return True
        else:
            return False

    def total_sum(self):
        '''Get the total value of a hand

        Returns:
            int : total value of the hand
        '''
        total = 0
        for card in self.cards:
            total += card.get_value(self.is_soft)
        return total

    def __str__(self):
        '''Presents a readable view of a hand'''
        total = 0
        cards = []
        for card in self.cards:
            cards.append(card.__str__())
            total += card.get_value(self.is_soft)
        output = "{:<15}, Totalt: {}".format(", ".join(cards), total)
        return output
