import random
from Card import Card


class Deck():
    '''A deck represents 52 cards'''

    def __init__(self):
        '''Generates a deck of cards'''
        self.cards = self.generate_deck()
        self.shuffle_deck()

    def generate_deck(self):
        '''Generates a fresh deck of cards

        Returns:
            list : a list of 52 cards
        '''
        cards = []
        for i in range(52):
            cards.append(Card(i))
        return cards

    def shuffle_deck(self):
        '''Shuffles the cards in the deck'''
        random.shuffle(self.cards)

    def take_card(self):
        '''Returns the first card in the deck'''
        return self.cards.pop()
