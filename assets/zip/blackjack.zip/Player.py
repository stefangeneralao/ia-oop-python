from CardPlayer import CardPlayer
from Hand import Hand


class Player(CardPlayer):
    '''A player in black jack

    Args:
        name (str) : name of the player
    '''

    def __init__(self, name, money):
        '''Creates an instance of Player

        Args:
            name (str) : the name of the player
            money (int) : the balance of the player
        '''
        self.balance = money
        super().__init__(name)

    def get_balance(self):
        '''Get the balance of a player

        Returns:
            int : the balance
        '''
        return self.balance

    def add_money(self, money):
        '''Adds money to the users balance

        Args:
            money (int) : The amount of money to be added

        returns:
            int : the new balance
        '''
        self.balance += money
        return self.balance

    def remove_money(self, money):
        '''Removes money to the users balance

        Args:
            money (int) : The amount of money to be removed

        returns:
            int : the new balance
        '''
        self.balance = self.balance - money
        return self.balance

    def __str__(self):
        '''Print at readable version of the player'''
        return "Namn: {}, Pengar: {}".format(self.name, self.balance)
