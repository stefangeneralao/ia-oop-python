from Product import *

class Usb(Product):

    def __init__(self, productnumber, name, price, size):
        # Send all inherited attributes to the super class
        # so that calculations can be made in Product (if needed)
        Product.__init__(self, productnumber, price, name)
        self.size = size

    def get_size(self):
        return self.size

    def set_size(self, size):
        self.size = size

    def __str__(self):
        return "%s (%s) - %sGB, price: %s" % (self.name,
                                              self.productnumber,
                                              self.size,
                                              self.price)
