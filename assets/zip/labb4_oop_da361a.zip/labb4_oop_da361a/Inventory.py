class Inventory(object):

    def __init__(self, products=[]):
        self.products = products

    def get_products(self):
        return self.products

    def add_product(self, product):
        self.products.append(product)
