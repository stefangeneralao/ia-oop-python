# Import dependencies
from Product import Product

# Software (subclass)
class Software(Product):
    """
    """

    def __init__(self, software_type=""):
        """
        """
        # Subclass specific attribute
        self.software_type = software_type

    def set_type(self, software_type):
        """
        """
        self.software_type = software_type

    def get_type(self):
        """
        """
        return self.software_type

    def __str__(self):
        """
        """
        return "%s - %s, %s, %s (%s)" % (self.name,
                                         self.manufacturer,
                                         self.category,
                                         self.software_type,
                                         str(self.price))

    def convert_to_csv(self):
        """
        Converts all the product information
        to the CSV format so we can store the
        information in a textfile and then retrieve it
        """
        return "%s,%s,%s,%s,%s" % (self.name,
                                   self.manufacturer,
                                   self.category,
                                   self.software_type,
                                   str(self.price))
