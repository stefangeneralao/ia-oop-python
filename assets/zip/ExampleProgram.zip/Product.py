# Product (base class)
class Product():
    """
    """

    def __init__(self, name="", manufacturer="", category="", price=0):
        """
        """
        self.name = name
        self.manufacturer = manufacturer
        self.category = category
        self.price = price

    def set_name(self, name):
        """
        """
        self.name = name

    def get_name(self):
        """
        """
        return self.name

    def set_manufacturer(self, manufacturer):
        """
        """
        self.manufacturer = manufacturer

    def get_manufacturer(self):
        """
        """
        return self.manufacturer

    def set_category(self, category):
        """
        """
        self.category = category

    def get_category(self):
        """
        """
        return self.category

    def set_price(self, price):
        """
        """
        self.price = price

    def get_price(self):
        """
        """
        return self.price
